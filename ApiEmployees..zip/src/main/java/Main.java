public class Main {
    public static void main(String[] args) {
        MainApp mainApp = new MainApp();
        mainApp.run();
    }
}
