public class Config {

    public static final String APP_URL = "http://dummy.restapiexample.com/api/v1/employees";
}
